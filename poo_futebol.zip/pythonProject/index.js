class Jogador {
    constructor(nome, posicao, idade, clube, anoContratacao) {
        this.nome = nome
        this.posicao = posicao
        this.idade = idade
        this.clube = clube
        this.anoContratacao = anoContratacao
    }
}

class CadastroJogadores {
    constructor() {
        this.jogadores = []
        this.jogadorEditando = null
    }

    adicionarJogador(jogador) {
        if (this.jogadorEditando) {
            const indice = this.jogadores.indexOf(this.jogadorEditando)
            this.jogadores[indice] = jogador
            this.jogadorEditando = null
        } else {
            this.jogadores.push(jogador)
        }
        this.atualizarTabela()
    }

    removerJogador(indice) {
        this.jogadores.splice(indice, 1)
        this.atualizarTabela()
    }

    editarJogador(indice) {
        const jogador = this.jogadores[indice]
        this.jogadorEditando = jogador

        document.getElementById('nome').value = jogador.nome
        document.getElementById('posicao').value = jogador.posicao
        document.getElementById('idade').value = jogador.idade
        document.getElementById('clube').value = jogador.clube
        document.getElementById('anoContratacao').value = jogador.anoContratacao
    }

    atualizarTabela() {
        const tabela = document.getElementById('tabelaJogadores')
        tabela.innerHTML = '';

        for (let i = 0; i < this.jogadores.length; i++) {
            const jogador = this.jogadores[i]
            const linha = document.createElement('tr')
            linha.innerHTML = `
                <td> ${jogador.nome}</td>
                <td> ${jogador.posicao}</td>
                <td> ${jogador.idade}</td>
                <td> ${jogador.clube}</td>
                <td> ${jogador.anoContratacao}</td>
                <td>
                   <button onclick="cadastroJogadores.editarJogador(${i})" class="btn btn-warning btn-sm">Editar</button>
                   <button onclick="cadastroJogadores.removerJogador(${i})" class="btn btn-danger btn-sm">Excluir</button>
                </td>
            `
            tabela.appendChild(linha)
        }
    }
}

const cadastroJogadores = new CadastroJogadores()
const formulario = document.getElementById('jogadorForm')

formulario.addEventListener('submit', function(evento){
    evento.preventDefault()

    const nome = document.getElementById('nome')
    const posicao = document.getElementById('posicao')
    const idade = document.getElementById('idade')
    const clube = document.getElementById('clube')
    const anoContratacao = document.getElementById('anoContratacao')

    const jogador = new Jogador(nome.value, posicao.value, idade.value, clube.value, anoContratacao.value)
    cadastroJogadores.adicionarJogador(jogador)
    console.log(cadastroJogadores.jogadores)
});